import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.math.BigInteger;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;


/*Creation Date- 7th March-2016.
 * Created by Kaivalya Vyas(Student# 800936482)
 * Below Class is used for encoding purpose for LZW algorithm.
 * This class has  main method  to put data in dictionary Array and output Array as per input string
 *  Also checkDictionary method checks that input data exists or not.
 * */

public class EncoderNew  {

	/**
	 * Main method that fethes 1 by 1 character and calls validation method
	 * for dictionary existance and gives outout
	 * @param args
	 */
	
	
	public static void main(String args[]) {
		
		
		UserInterface u = new UserInterface();
		
		int CMDBitLenght = (int)Math.pow(2,u.mainbitlenght);
		System.out.println("bit lenght cmd"+CMDBitLenght);
        
		int bitLenght = CMDBitLenght;//for 12 bit length
		String[] InputArray = new String[bitLenght];

		System.out.println("");
		String input = "";
		
		BufferedReader br = null;

		try {

			String sCurrentLine;
      System.out.println(""+u.filename);
			br = new BufferedReader(new FileReader(u.filename));
          
			while ((sCurrentLine = br.readLine()) != null) {
				 input = sCurrentLine;
      			System.out.println(sCurrentLine);
			}

		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				if (br != null)br.close();
			} catch (IOException ex) {
				ex.printStackTrace();
			}
		}
		
		
		String[] Dictionary = new String[bitLenght]; // Array that stores dictionary from input string 
		int[] Dictionary_number = new int[bitLenght];
		String[] OutputArray = new String[bitLenght]; // Array that stores output from input string
		
	    ArrayList<String> dictionaryListString = new ArrayList<String>(); // Array List for Dictionary to resolve indexing issue
		ArrayList<String> OPListString = new ArrayList<String>();	// Array List for OP List to resolve indexing issue	
		ArrayList<Integer> FinalOPListString = new ArrayList<Integer>(); // Array List for Final OP List to resolve indexing issue
		
		
		String ecn = "";   //variable to identify end of String
		int t = 0;  //temp variable that tracks matching string found or not?
		
		
		// Loop that runs for Each inout character and inserts data in current/ Output and Dictionary Arrays/ArrayLists
        for (int i = 0; i < input.length(); i++) {
			//System.out.println("Main iteration  " + i);
			String c;
			String n;
			String cn = "";

			if (i <= input.length()) {
				boolean b;

				if (t == 0) {
					if (i + 1 == input.length()) {
						c = String.valueOf(input.charAt(i));
						// n = String.valueOf(input.charAt(i+1));
						n = "";
						c = Dictionary[0]; // deliberately putting first value
											// so it gets repeated
					} else {
					//	System.out.println("temp");
						c = String.valueOf(input.charAt(i));
						n = String.valueOf(input.charAt(i + 1));
					}

					if (i == input.length() - 1) {
						//System.out.println("in last kdv curr"+c);
						//OutputArray[i] = c.concat(n);
						OutputArray[i] = c;						
					}

					cn = c.concat(n);
				//	System.out.println("in 0");
				//	System.out.println("in 0 " + cn);
					b = new EncoderNew().checkDictionary(cn, Dictionary);
                  System.out.println(""+b);
				} else {
					if (i >= input.length() - 1) {

						c = ecn;
						n = "";
						cn = c.concat(n);
					} else {

						c = ecn;
						n = String.valueOf(input.charAt(i + 1));
						cn = c.concat(n);
					}
					if (i == input.length() - 1) {
						
					OutputArray[i + 1] = cn;
					
					}
				//Calls CheckDictionary method for verifying cn exists in Dictionary or not.
					b = new EncoderNew().checkDictionary(cn, Dictionary);
				}

				// if string not exists then inserts data in dictionary
				if (b == false) {
					String temp = cn.substring(0, cn.length() - 1);
					System.out.println("in false" +temp);
					
					OutputArray[i] = temp;
					Dictionary[i] = cn;
					if(i>0 && Dictionary[i-1] == null)
					{
						
					}
					else
					{
						
					}
					int x = CMDBitLenght+i;
					Dictionary_number[i] =x ;
					

					t = 0;

				}

				// if string  exists then  it is exceptional scenario . after scenario handle it inserts data in dictionary
				else {
                 	ecn = cn;
					t = 1;
									}

			}

			else {

			}

		}
        
//Display of Dictionary Array in string
        int xtmp = 0;
		for (int i = 0; i < Dictionary.length; i++) {
			if (Dictionary[i] != null)
			{
				
				int x = bitLenght+i;
			//   System.out.println(""+i);
			//	System.out.println("Dictionary in string"+Dictionary[i]);
				
				dictionaryListString.add(Dictionary[i]+""+"|"+xtmp);
				xtmp=xtmp+1;
			}
			
			
		}

		int ytmp = 0;
		//display of output array in string
		for (int i = 0; i < OutputArray.length; i++) {
			if (OutputArray[i] != null)
			{
				//System.out.println("Output in String"+i);
				//System.out.println("Output in String" + OutputArray[i]);
				OPListString.add(OutputArray[i]+""+"|"+ytmp);
				ytmp = ytmp+1;
				//Integer it = new Integer("");
				
				//int a = Integer.parseInt(s);
				//OPList.add(a);
			}
		}
		
		
		
		for(int i =0;i<OPListString.size();i++)
		{
			//System.out.println("OPList List"+i);
			//System.out.println("OPList List"+OPListString.get(i));
			
		}
		
	    
		for(int i =0;i<dictionaryListString.size();i++)
		{
			//System.out.println("Dictionary List"+i);
			//System.out.println("Dictionary List"+dictionaryListString.get(i));
			
		}
		
		int x = 0;
		for(int k =0;k<OPListString.size();k++)
		{
			for(int j =0;j<dictionaryListString.size();j++)
			{
				
				if(OPListString.get(k).substring(0, OPListString.get(k).indexOf("|")).length() == 1)
				{
				//	System.out.println("Match found in dictionary simple"+OPListString.get(k).substring(0, OPListString.get(k).indexOf("|")));
					 x =  (int)OPListString.get(k).substring(0, OPListString.get(k).indexOf("|")).charAt(0);
				//	System.out.println(""+x);
					//FinalOPListString.add(x);
				}
				
				if(OPListString.get(k).substring(0, OPListString.get(k).indexOf("|")).equals(dictionaryListString.get(j).substring(0, dictionaryListString.get(j).indexOf("|"))))
				{
				      x = CMDBitLenght+ Integer.parseInt(dictionaryListString.get(j).substring(dictionaryListString.get(j).indexOf("|")+1,dictionaryListString.get(j).length() ));
                     // System.out.println(""+x);
				}
			}
			
			
			FinalOPListString.add(x);
		}
		
		
		

		
		
         String final_output = "";
         String Encoded_Output = "";
		for(int l = FinalOPListString.size()-1;l>=0;l--)
		{
			
			System.out.println("Final OP  "+FinalOPListString.get(l));
		System.out.println(""+Integer.toString(FinalOPListString.get(l),2));	
		
		final_output=Integer.toString(FinalOPListString.get(l),2)+" "+final_output;
		
	//	final_output=FinalOPListString.get(l).toString()+" "+final_output;  // very imp
			
		}
		
		
		try{
		
		
		File file = new File(u.filename.substring(0,u.filename.length()-4).concat(".lzw"));
		// if file doesnt exists, then create it
		if (!file.exists()) {
			file.createNewFile();
		}

		System.out.println(""+final_output);
		FileWriter fw = new FileWriter(file.getAbsoluteFile());
		BufferedWriter bw = new BufferedWriter(fw);
		bw.write(final_output);
		bw.close();

		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
		
		}

	public boolean checkDictionary(String c, String[] dictionaryy) {
		
		//This method checks that input data exists in directory or not
		//method returns true if match found and false if not found
		boolean check = false;
        int count = 0;

        //loop that travers to entire dictionary
		for (int k = 0; k < dictionaryy.length; k++) {

			if (dictionaryy[k] != null) {

				System.out.println("input value " + c + "value of k is " + k);
				System.out.println("dictionary value" + dictionaryy[k]);	
				
				if (dictionaryy[k].equals(c)) {
					System.out.println("match found");
				//count is updated to convey that match is founded	
					count = 1;
				}
			}

		}

		if (count > 0) {
			check = true;
		}

		return check;
	}

}
