import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

/*Creation Date- 9th March-2016.
 * Created by Kaivalya Vyas(Student# 800936482)
 * Below Class is used for decoding purpose for LZW algorithm.
 * This class first validates for exceptional case and then inserts data in dictionary 
 *  
 * */

public class Decoder {

	public static void main(String args[]) {
		

        UserInterface u = new UserInterface();
		int CMDBitLenght = (int)Math.pow(2,u.mainbitlenght);
		System.out.println("bit lenght cmd"+CMDBitLenght);
		
		int bitLenght = CMDBitLenght;
		BufferedReader br = null;
			String s1 = "";

		try {

			String sCurrentLine;

			br = new BufferedReader(new FileReader(u.filename.substring(0,u.filename.length()-4).concat(".lzw")));

			while ((sCurrentLine = br.readLine()) != null) {
				
				
				System.out.println(sCurrentLine);
				s1 = sCurrentLine;
			}

		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				if (br != null)br.close();
			} catch (IOException ex) {
				ex.printStackTrace();
			}
		}

		
		String delims1 = "[ ]";
		String[] parts1 = s1.split(delims1);
		 int[] tempInput = new int[parts1.length];
		for(int i = 0;i<parts1.length;i++)
		{
			double foo = Integer.parseInt(parts1[i], 2);
			System.out.println(""+foo);
			tempInput[i] = (int)foo;
			//String out = String.valueOf(parts1[i]);
		//	System.out.println(Integer.parseInt(out));
			//tempInput[i]=Integer.parseInt(parts1[i]);  VIMP
		}

		
		
		// int[] current =new int[bitLenght]; //current
		// int[] tempInput = {97,98,4097,CMDBitLenght};
		// int[] tempInput = {97,98,99,4097};
	//	int[] tempInput = { 97, 98, CMDBitLenght, 4098 }; // Input from encoded file

		int[] next = new int[bitLenght]; // Stores data for next input
		int[] output = new int[bitLenght]; // Stores data for Output
		String[] dictionary = new String[bitLenght]; // String Array that stores
														// data for Dictionary

		// Assignment in Next array
		for (int i = 1; i < tempInput.length; i++) {
			next[i - 1] = tempInput[i];
			// System.out.println("vlue of next is" + next[i - 1]);
		}
		// Assignment in Outout
		for (int i = 0; i < tempInput.length; i++) {
			output[i] = tempInput[i];
			// System.out.println("vlue of output is" + output[i]);
		}

		/*
		 * Assignment in dictionary Below loop also verifies exceptional
		 * scenario by case 1 to case 4 and then adds data in dictionary.
		 */
		for (int i = 0; i < tempInput.length - 1; i++) {

			if (tempInput[i] > CMDBitLenght-1 && next[i] > CMDBitLenght-1) {
				// System.out.println("case1 where current and next value needs to be get from dictionary");
				// below code fragment check if dictionary value is defined or
				// not if not and accordingly gets data.
				if (dictionary[tempInput[i] - CMDBitLenght] == null) {

					if (tempInput[i] < CMDBitLenght) {
						dictionary[tempInput[i] - CMDBitLenght] = String
								.valueOf(tempInput[i])
								+ "|"
								+ String.valueOf(tempInput[i]);

					} else {

						if (dictionary[tempInput[i] - CMDBitLenght] == null) {
							dictionary[tempInput[i] - CMDBitLenght] = String
									.valueOf(tempInput[i])
									+ "|"
									+ String.valueOf(tempInput[i]);

						} else {
							dictionary[tempInput[i] - CMDBitLenght] = dictionary[tempInput[i] - CMDBitLenght]
									+ "|"
									+ dictionary[tempInput[i] - CMDBitLenght]
											.substring(
													0,
													dictionary[tempInput[i] - CMDBitLenght]
															.indexOf("|"));

						}

					}
				} else if (dictionary[next[i] - CMDBitLenght] == null) {

					if (tempInput[i] < CMDBitLenght) {

						dictionary[next[i] - CMDBitLenght] = String
								.valueOf(tempInput[i])
								+ "|"
								+ String.valueOf(tempInput[i]);

					} else {
						if (dictionary[tempInput[i] - CMDBitLenght] == null) {
							dictionary[next[i] - CMDBitLenght] = String
									.valueOf(tempInput[i])
									+ "|"
									+ String.valueOf(tempInput[i]);

						} else {
							dictionary[next[i] - CMDBitLenght] = dictionary[tempInput[i] - CMDBitLenght]
									+ "|"
									+ dictionary[tempInput[i] - CMDBitLenght]
											.substring(
													0,
													dictionary[tempInput[i] - CMDBitLenght]
															.indexOf("|"));

						}

					}

				} else {

					dictionary[i] = dictionary[tempInput[i] - CMDBitLenght] + "|"
							+ dictionary[next[i] - CMDBitLenght];
					System.out.println("case1");
				}
			} else if (next[i] > CMDBitLenght-1 && tempInput[i] <= CMDBitLenght-1) {

				// below code fragment checks if dictionary value is defined or
				// not if not and accordingly gets data.

				System.out
						.println("case2  where next value is from dictionary array and current is from input array");
				if (dictionary[next[i] - CMDBitLenght] == null) {

					if (next[i] < CMDBitLenght) {
						dictionary[next[i] - CMDBitLenght] = String
								.valueOf(tempInput[i])
								+ "|"
								+ String.valueOf(tempInput[i]);

					} else {
						if (dictionary[tempInput[i]] == null) {
							dictionary[next[i] - CMDBitLenght] = String
									.valueOf(tempInput[i])
									+ "|"
									+ String.valueOf(tempInput[i]);

						} else {
							dictionary[next[i] - CMDBitLenght] = dictionary[tempInput[i] - CMDBitLenght]
									+ "|"
									+ dictionary[tempInput[i] - CMDBitLenght]
											.substring(
													0,
													dictionary[tempInput[i] - CMDBitLenght]
															.indexOf("|"));
						}
					}

				} else {
					dictionary[i] = tempInput[i] + "|"
							+ dictionary[next[i] - CMDBitLenght];

				}
			} else if (next[i] <= CMDBitLenght-1 && tempInput[i] > CMDBitLenght-1) {
				System.out
						.println("case3 input is from dictionary and next is defined in next array ");
				// below code fragment checks if dictionary value is defined or
				// not if not and accordingly gets data.

				if (dictionary[tempInput[i] - CMDBitLenght] == null) {
					// dictionary[tempInput[i]-CMDBitLenght] =
					// String.valueOf(tempInput[i])+"|"+String.valueOf(tempInput[i]);

					if (tempInput[i] < CMDBitLenght) {
						dictionary[tempInput[i] - CMDBitLenght] = String
								.valueOf(tempInput[i])
								+ "|"
								+ String.valueOf(tempInput[i]);

					} else {
						if (dictionary[tempInput[i] - CMDBitLenght] == null) {
							dictionary[tempInput[i] - CMDBitLenght] = String
									.valueOf(tempInput[i])
									+ "|"
									+ String.valueOf(tempInput[i]);

						} else {
							dictionary[tempInput[i] - CMDBitLenght] = dictionary[tempInput[i] - CMDBitLenght]
									+ "|"
									+ dictionary[tempInput[i] - CMDBitLenght]
											.substring(
													0,
													dictionary[tempInput[i] - CMDBitLenght]
															.indexOf("|"));

						}

					}

				} else {
					dictionary[i] = dictionary[tempInput[i] - CMDBitLenght] + "|"
							+ next[i];

				}
			} else {

				System.out
						.println("case4 simple case where current an next both are defined and from curr/next array it self");

				// No need to check for exceotinal case as it is simple input
				// and next value from array
				dictionary[i] = tempInput[i] + "|" + next[i];
			}

			// System.out.println("vlue of dictionary is" + dictionary[i]);
			// System.out.println("vlue of dictionary is" + i);
		}
		// Data loaded in dictionary

		// final_output string preparing code
		String final_output = "";
		for (int k = 0; k < output.length; k++) {
			if (output[k] > 0) {
				if (output[k] > CMDBitLenght-1) {
					String s = dictionary[output[k] - CMDBitLenght];
					int counter = 0;

					// code that finds delimeter and generates seperate o/p
					// finds count
					for (int i = 0; i < s.length(); i++) {
						if (s.charAt(i) == '|') {
							counter++;

						}
					}
					String delims = "[|]";
					String[] parts = s.split(delims);

					// prepares string to write on file
					for (int i = 0; i < parts.length; i++) {
						System.out.println("final out put if" + parts[i]);
						int x = Integer.parseInt(parts[i]);

						// System.out.println(""+Character.toString(c));
						final_output = final_output + ""
								+ Character.toString((char) x);
					}

				} else {
					// System.out.println(""+k);
					System.out.println("final output else" + output[k] + "|"
							+ k);

					if (k == 0) {
						final_output = final_output + ""
								+ Character.toString((char) output[k]);
					} else {
						final_output = final_output + ""
								+ Character.toString((char) output[k]);

					}
				}
			}
		}

		// final_output string preparing code completed

		try {

			

			File file = new File(u.filename.substring(0,u.filename.length()-4).concat("_decoded.txt"));
			// if file doesnt exists, then create it
			if (!file.exists()) {
				file.createNewFile();
			}

			System.out.println("" + final_output);
			FileWriter fw = new FileWriter(file.getAbsoluteFile());
			BufferedWriter bw = new BufferedWriter(fw);
			bw.write(final_output);
			bw.close();

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
