import java.util.Scanner;
/* Created by Kaivalya Vyas(Student# 800936482)
 * File created on 15th MArch 2016.
 * It is just a user interface program
 * */

public class UserInterface {
	
	public static int mainbitlenght = 0;
	public static String filename = "";
	public static void main(String args[])
	{
		// below code creates object to access main method of both classes
		EncoderNew e = new EncoderNew();
		Decoder d = new Decoder();
		
		// below code reads data from user
		Scanner reader = new Scanner(System.in);  // Reading from System.in
		System.out.println("Enter File Name then Space followed by bit length  eg. input1.txt 12 for encoding / input1.lzw 12 for decoding");
		
		String n = reader.next();
		int m = reader.nextInt();
		
		mainbitlenght = m;
		filename = n;
		
		// based on input decoder should call / Encoder should call is decided.
		
		if(n.contains("lzw"))
		{
			d.main(args);		
		}
		else
		{

			e.main(args);
			
		}
		
		
	}
	
	

}

